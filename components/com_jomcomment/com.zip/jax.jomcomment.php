<?php

global $jaxFuncNames;
if (!is_array($jaxFuncNames)) $jaxFuncNames = array();

$jaxFuncNames[] = "jcxLoadUserInfo";
$jaxFuncNames[] = "jcxAddComment";
$jaxFuncNames[] = "jcxUpdateComment";
$jaxFuncNames[] = "jcxUnpublish";
$jaxFuncNames[] = "jcxEdit";
$jaxFuncNames[] = "jcxSave";
$jaxFuncNames[] = "jcxReport";

$jaxFuncNames[] = "jcxEditComment";
$jaxFuncNames[] = "jcxTrainFilter";
$jaxFuncNames[] = "jcxTrainFilterTest";
$jaxFuncNames[] = "jcxBanUserName";
$jaxFuncNames[] = "jcxBanUserIP";
$jaxFuncNames[] = "jcxTogglePublish";
$jaxFuncNames[] = "jcxLoadLangFile";
$jaxFuncNames[] = "jcxSaveLanguage";
$jaxFuncNames[] = "jcxTrainTrackbackFilter";
$jaxFuncNames[] = "jcxTrainTrackbackFilterTest";
$jaxFuncNames[] = "jcxToggleTrackbackPublish";
$jaxFuncNames[] = "jcxSaveComment";
$jaxFuncNames[] = "jcxDoPatch";

