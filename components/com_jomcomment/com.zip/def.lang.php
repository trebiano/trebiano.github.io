<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );

function jcLang
