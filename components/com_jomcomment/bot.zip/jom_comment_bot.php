<?php
defined('_VALID_MOS') or die('Direct Access to this location is not allowed.');

global $mosConfig_absolute_path;
include($mosConfig_absolute_path . '/components/com_jomcomment/mambots.php');
