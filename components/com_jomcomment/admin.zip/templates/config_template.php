<form action="index2.php?option=com_jomcomment&task=config" method="POST" name="adminForm">
  <table cellpadding="4" cellspacing="0" border="0" width="100%">
  <tr>
    <td width="100%" class="sectionname">
      <img src="components/com_jomcomment/logo.png">
    </td>
  </tr>
  </table>
<div style="width:860px">
<?php
	$tabs = new mosTabs(1);
	$tabs->startPane("jom_comment");
	$tabs->startTab("General", "General-page");
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0"  class="mytable">
  <th colspan="3">Basic Settings </th>
  <tr  class="row0">
    <td width="23%"><b>Enable Jom Comment:</b></td>
    <td width="25%"><?php echo mosHTML::yesnoRadioList( 'enable', 'class="inputbox"', $_JC_CONFIG->get('enable') ); ?></td>
    <td width="52%">Select 'No' if you want to temporarily disable Jom Comment system. </td>
  </tr>
  <tr class="row1">
    <td><b>Languages</b></td>
    <td><?php echo $languages; ?>&nbsp;<br />
        or automatically select<br />        <?php echo mosHTML::yesnoRadioList( 'autoLang', 'class="inputbox"', $_JC_CONFIG->get('autoLang')); ?></td>
    <td>Choose a language to set your comment system. Select 'auto' to force Jom Comment to use preferred system/user language. </td>
  </tr>
  <!--
  <tr>
    <td><b>Support multilanguage input:</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'multiLanguage', 'class="inputbox"', $_JC_CONFIG->get('multiLanguage') ); ?></td>
    <td>Select 'Yes' if you site would like to support input in multiple, different encoding. You normally do not need this feature. Default:'No'</td>
  </tr>
  -->
  <tr>
    <td><b>Auto publish:</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'autoPublish', 'class="inputbox"', $_JC_CONFIG->get('autoPublish')); ?></td>
    <td>Choosing 'Yes' will make new comments appear automatically in page. Select 'No' if you want to moderate the comment before approving them. </td>
  </tr>
  <tr class="row1">
    <td><b>Allow guest to comment:</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'anonComment', 'class="inputbox"', $_JC_CONFIG->get('anonComment') ); ?></td>
    <td>Choosing 'Yes' will allow guest to comment without registering to your site</td>
  </tr>
  <tr>
    <td><b>Moderate guest&rsquo;s comment:</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'modGuest', 'class="inputbox"', $_JC_CONFIG->get('modGuest') ); ?></td>
    <td>Choosing 'Yes' will allow comments by guest (unregistered visitors) to be unpublished. Admin will be warned through email.</td>
  </tr>
  <tr class="row1">
    <td><b>Enable comment feed (RSS):</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'useRSSFeed', 'class="inputbox"', $_JC_CONFIG->get('useRSSFeed') ); ?></td>
    <td>A unique RSS feed link will be created and maintained. </td>
  </tr>
  <tr>
    <td><b>Enable support for 3rd party component:</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'extComSupport', 'class="inputbox"', $_JC_CONFIG->get('extComSupport') ); ?></td>
    <td>If you do not use Jom Comment on any 3rd party component other than My Blog, you can set this to 'No'. This will stop related JavaSript from being added to the component page. Set this to 'Yes' if you use any 3rd party component integration feature</td>
  </tr>
  <tr  class="row1">
    <td colspan="3">&nbsp;</td>
  </tr>
  <th colspan="3">Smilies and BBCode</th>
  <tr>
    <td><b>Use BB code:</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'useBBCode', 'class="inputbox"', $_JC_CONFIG->get('useBBCode') ); ?></td>
    <td>Choosing 'Yes' will display BB code such as smilies, <strong>bold, </strong><em>italic, </em>etc.. </td>
  </tr>
  <tr class="row1">
    <td><b>Use Smilies:</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'useSmilies', 'class="inputbox"', $_JC_CONFIG->get('useSmilies') ); ?></td>
    <td>Choosing 'Yes' will convert smilies such as :), :P etc.. to image based smilies </td>
  </tr>
  <tr>
    <td><b>Allow HTML tag</b></td>
    <td><textarea id="allowedTags" name="allowedTags" rows="4" cols="45" class="inputbox"><?php echo $_JC_CONFIG->get('allowedTags') ?></textarea></td>
    <td>HTML tags you would allow user to add. For example, '&lt;p&gt;&lt;b&gt;&lt;em&gt;'. There is no need to add the closing tag.</td>
  </tr>
  
  <!--
  <tr>
    <td><b>Enable auto update:</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'autoUpdate', 'class="inputbox"', $_JC_CONFIG->get('autoUpdate') ); ?></td>
    <td>If 'Yes' is selected, the whole comment will be refresh after the given interval. On a really high traffic site, you might want to disable it. </td>
  </tr>
  
  <tr>
    <td><b>Maximum comment per page</b><br/> Set to 0, to display all comments at once</td>
    <td><input class="inputbox" type="text" name="paginate" size="8" maxlength="4" value="<?php echo $_JC_CONFIG->get('paginate'); ?>" /></td>
    <td></td>
  </tr>
  
  <tr>
    <td><b>Allow email subscription</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'useEmailSubs', 'class="inputbox"', $_JC_CONFIG->get('useEmailSubs') ); ?></td>
    <td>Choosing 'Yes' will allow member to receive an email when a new comment is added.</td>
  </tr>
  
  <tr>
    <td><b>Update period (seconds):</b></td>
    <td><input class="inputbox" type="text" name="updatePeriod" size="5" maxlength="3" value="<?php echo $_JC_CONFIG->get('updatePeriod') ?>" /></td>
    <td>&nbsp;</td>
  </tr>-->
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
      <th colspan="3">Fields to show </th>
  <tr>
    <td><b>Require name:</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'moreInfo', 'class="inputbox"', $_JC_CONFIG->get('moreInfo') ); ?></td>
    <td>Choosing 'Yes' will display fields to enter name. </td>
  </tr>
  <tr class="row1">
    <td><b>Require email:</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'fieldEmail', 'class="inputbox"', $_JC_CONFIG->get('fieldEmail') ); ?></td>
    <td>Choosing 'Yes' will display fields to enter e-mail. The e-mail entered will need to be a valid e-mail address.</td>
  </tr>
  <tr>
  	<td><b>Name field to use</b></td>
	<td><?php echo $name_field; ?></td>
	<td>Select to use either user's real name or their login name. This doesn't affect unregistered user. </td>
  </tr>
  <tr class="row1">
    <td><b>Show website field:</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'fieldWebsite', 'class="inputbox"', $_JC_CONFIG->get('fieldWebsite') ); ?></td>
    <td>Choosing 'Yes' will display website field (optional). </td>
  </tr>
  <tr>
    <td><b>Show title field:</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'fieldTitle', 'class="inputbox"', $_JC_CONFIG->get('fieldTitle') ); ?></td>
    <td>Choosing 'Yes' will display title field (optional)</td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
      <th colspan="3">Sections (which content do you want the comment area to appear?) </th>
  <tr>
    <td><b>Comment static content</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'staticContent', 'class="inputbox"', $_JC_CONFIG->get('staticContent') ); ?></td>
    <td>Allow visitor to add comment on all static content </td>
  </tr>
  <!--
  <tr class="row1">
    <td><b>Limit comment on the following categories</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'limitSection', 'class="inputbox"', $_JC_CONFIG->get('limitSection') ); ?></td>
    <td>&nbsp;</td>
  </tr>
  -->
  <tr>
    <td><b>Limit comment on the following categories</b></td>
    <td><?php echo $category_list; /*sections*/ ?></td>
    <td>&nbsp;</td>
  </tr>
   <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <th colspan="3">Notification </th>
  <tr>
    <td><b>Notify admin on new post:</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'notifyAdmin', 'class="inputbox"', $_JC_CONFIG->get('notifyAdmin') ); ?></td>
    <td>Send email to the specified address whenever a new comment is posted. If you disable the auto-publish feature, you might want to enable this. </td>
  </tr>
  <tr>
    <td><b><label for="notifyEmail">Notification email:</label></b></td>
    <td><input class="inputbox" type="text" id="notifyEmail" name="notifyEmail" size="48" maxlength="128" value="<?php echo $_JC_CONFIG->get('notifyEmail'); ?>" /></td>
    <td>Specify where the notification email should be send. </td>
  </tr>
  <tr>
    <td><b>Notify author on new post:</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'notifyAuthor', 'class="inputbox"', $_JC_CONFIG->get('notifyAuthor') ); ?></td>
    <td>Send e-mail to the article author whenever a new comment is posted.</td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
</table>
   
  <?php

	$tabs->endTab();
	$tabs->startTab("Spam", "Spam Control -page");
	////////////////////////////////////////////////////////////////////////////
?>

<table width="100%" border="0" cellspacing="0" cellpadding="0" class="mytable" >
	<tr class="row1">
    	<td width="22%"><b>Use Akismet spam detection service</b></td>
	    <td width="34%"><?php echo mosHTML::yesnoRadioList( 'remoteSpam', 'class="inputbox"', $_JC_CONFIG->get('remoteSpam') ); ?></td>
	    <td width="44%" valign="top">Choose 'Yes' to check each comment and trackback post against Akismet spam database. 
		Although spam detection accuracy will be improved significantly, it does take a few seconds to complete. You also need to obtain access 
		key from www.wordpress.com .  
		</td>
	</tr>
  
  <tr>
    <td><b>Akismet access key</b></td>
    <td><input class="inputbox" type="text" name="akismetKey" size="25" maxlength="128" value="<?php echo $_JC_CONFIG->get('akismetKey'); ?>" /></td>
    <td>Akismet access key. You need an account with www.wordpress.com to obtain an access key.</td>
  </tr>
  
  <tr class="row1">
    <td width="22%"><b>Enable captcha image security:</b></td>
    <td width="34%"><?php echo mosHTML::yesnoRadioList( 'useCaptcha', 'class="inputbox"', $_JC_CONFIG->get('useCaptcha') ); ?></td>
    <td width="44%" valign="top">Choosing 'Yes' will display Captcha image the comment, where poster needs to verify in order to post comment</td>
  </tr>
  <tr>
    <td width="22%"><b>Enable captcha for registered user:</b></td>
    <td width="34%"><?php echo mosHTML::yesnoRadioList( 'useCaptchaRegistered', 'class="inputbox"', $_JC_CONFIG->get('useCaptchaRegistered') ); ?></td>
    <td width="44%" valign="top">Choosing 'No' will disable captcha for registered member</td>
  </tr>
  <tr class="row1">
    <td><b>Minimum comment length</b></td>
    <td><input class="inputbox" type="text" name="commentMinLen" size="25" maxlength="128" value="<?php echo $_JC_CONFIG->get('commentMinLen'); ?>" /></td>
    <td>The minimum number of character(s) a user can post. </td>
  </tr>
  <tr>
    <td><b>Maximum comment length</b></td>
    <td><input class="inputbox" type="text" name="commentMaxLen" size="25" maxlength="128" value="<?php echo $_JC_CONFIG->get('commentMaxLen'); ?>" /></td>
    <td>The maximum number of character(s) a user can post. </td>
  </tr>
  <tr class="row1">
    <td  valign="top"><b><label for="blockDomain">Block the following domain or IP:</label></b><br/>Separate by comma</td>
    <td><textarea id="blockDomain" name="blockDomain" rows="4" cols="45" class="inputbox"><?php echo $_JC_CONFIG->get('blockDomain') ?></textarea></td>
    <td valign="top">If you wish to block a certain user, you may block his domain or IP address and the poster will not be able to post at your website again.</td>
  </tr>
  <tr>
    <td  valign="top"><b><label for="blockUsers">Block the username:</label></b><br/>Separate by comma</td>
    <td><textarea id="blockUsers" name="blockUsers" rows="4" cols="45" class="inputbox"><?php echo $_JC_CONFIG->get('blockUsers') ?></textarea></td>
    <td valign="top">If you wish to block a certain user, you can enter his/her username here.</td>
  </tr>
  <tr class="row1">
    <td  valign="top"><b><label for="blockWords">Blocked words:</label></b><br/>Separate by comma</td>
    <td><textarea id="blockWords" name="blockWords" rows="4" cols="45" class="inputbox"><?php echo $_JC_CONFIG->get('blockWords') ?></textarea></td>
    <td valign="top">If a posting contains any of the specified words, it will automatically be unpublished and e-mail notification will be sent to admin.</td>
  </tr>
  <tr>
    <td  valign="top"><b>Censored words:</b><br/>Separate by comma</td>
    <td><textarea name="censoredWords" rows="4" cols="45" class="inputbox"><?php echo $_JC_CONFIG->get('censoredWords') ?></textarea></td>
    <td valign="top">All censored words will appear as **** . For example, 'censored' will appear as c******d.</td>
  </tr>
  
  <tr class="row1">
    <td><b>Add 'rel=nofollow' on outgoing links</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'linkNofollow', 'class="inputbox"', $_JC_CONFIG->get('linkNofollow') ); ?></td>
    <td>Add "rel=nofollow" to all outgoing links. Search engine will not follow links when crawling your site.</td>
  </tr>
  <th colspan="3">Spam detection</th>
  <tr>
    <td><b>Interval between post, (Flood control)</b></td>
    <td><input class="inputbox" type="text" name="postInterval" size="25" maxlength="25" value="<?php echo $_JC_CONFIG->get('postInterval'); ?>" /></td>
    <td valign="top">Allow a time interval (in seconds) in between postings to deter comment flooding.</td>
  </tr>
  <tr class="row1">
    <td><b>Max. number of links</b></td>
    <td><input class="inputbox" type="text" name="spamMaxLink" size="25" maxlength="25" value="<?php echo $_JC_CONFIG->get('spamMaxLink'); ?>" /></td>
    <td valign="top">Maximum number of link(s) that can appear in a comment before it is marked as Spam</td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
</table>
<?php

	$tabs->endTab();
	$tabs->startTab("Extra", "Trackback Control -page");
	////////////////////////////////////////////////////////////////////////////
?>

<table width="100%" border="0" cellspacing="0" cellpadding="0" class="mytable" >
  <tr><th colspan="3">Trackback support</th></tr>
  <tr>
    <td width="70%" colspan="2">
	<p>Trackback feature allow other blog or site to notify 
	you that they have either quoted, discuss, refer to or have similar content as 
	your article. Normally, the more sites ping and link back to you, the more 
	credible your article will be.
	</p>
	</td>
    <td width="30%"></td>
  </tr>
  <tr class="row1">
    <td width="22%"><b>Enable trackback</b></td>
    <td width="34%"><?php echo mosHTML::yesnoRadioList( 'enableTrackback', 'class="inputbox"', $_JC_CONFIG->get('enableTrackback') ); ?></td>
    <td width="44%" valign="top"></td>
  </tr>
  <tr>
    <td width="22%"><b>Require a link to your site:</b></td>
    <td width="34%"><?php echo mosHTML::yesnoRadioList( 'useLinkback', 'class="inputbox"', $_JC_CONFIG->get('useLinkback') ); ?></td>
    <td width="44%" valign="top">
		Choose 'Yes' to only accept trackback that actually contain a link to your website.<br/>
		This will significantly reduce the amount of trackback Spam.
	</td>
  </tr>
   <tr>
    <td width="70%" colspan="3">&nbsp;</td>
  </tr>
  <tr><th colspan="3">Comment locking</th></tr>
  <tr>
    <td width="70%" colspan="2"><p>If you want, you can set Jom Comment to disable comment
	input after a specified number of days. This feature would be useful in a situation
	where a discussion would be irrelevant after a number of days. 
	</p>
	    <p>You can also control comment locking manually by inserting the following tag into the content text itself.</p>
	<ul>
	    <li>{jomcomment   lock} : completely lock the comment area</li>
	</ul>

	</td>
    <td width="30%"></td>
  </tr>
  <tr class="row1">
    <td><b>Disable comment posting after</b></td>
    <td><input class="inputbox" type="text" name="lockAfter" size="10" maxlength="10" value="<?php echo $_JC_CONFIG->get('lockAfter'); ?>" /> days</td>
    <td>Set to 0 to disable locking feature</td>
  </tr>
  <tr>
    <td width="70%" colspan="3">&nbsp;</td>
  </tr>
  <tr><th colspan="3">Character Encoding</th></tr>
  <tr>
    <td width="70%" colspan="2"><p>Set to 'Yes' to optimize the output encoding. 
	Jom Comment will try to use the most efficient encoding. Set it to 'No' if 
	you are having problem with the output displayed.
	</p>
	</td>
    <td width="30%"></td>
  </tr>
  <tr class="row1">
    <td><b>Optimize output encoding</b></td>
    <td width="34%"><?php echo mosHTML::yesnoRadioList( 'optimiseEncoding', 'class="inputbox"', $_JC_CONFIG->get('optimiseEncoding') ); ?></td>
    <td></td>
  </tr>
  <tr>
    <td width="70%" colspan="3">&nbsp;</td>
  </tr>
</table>

    <?php

	$tabs->endTab();
	$tabs->startTab("Layout", "Layout-page");
	////////////////////////////////////////////////////////////////////////////////    
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0"  class="mytable" >
<th colspan="3"><b>Templates</b></h>
  <tr>
    <td width="21%"><b>Template</b></td>
    <td width="35%"><?php echo $templates; ?></td>
    <td width="44%"><p>Choose a template you wish to use for Jom Comment.<br />
        Only 1 default template is provided in the free version. The professional version contain 8 different, prefessionally designed templates. </p>
        </td>
  </tr>
  <tr class="row1">
    <td><b>Ordering</b></td>
    <td><?php

	$msg_order[] = mosHTML :: makeOption('1', 'Older first');
	$msg_order[] = mosHTML :: makeOption('0', 'Newer first');
	$msg_ordering = mosHTML :: selectList($msg_order, 'sortBy', 'class="inputbox" size="2"', 'value', 'text', $_JC_CONFIG->get('sortBy'));
	echo $msg_ordering;
?>    </td>
    <td>Choose the ordering of your comment posts.</td>
  </tr>
  <tr>
    <td><b>Cycle comment css</b></td>
    <td><input class="inputbox" type="text" name="cycleStyle" size="50" maxlength="50" value="<?php echo $_JC_CONFIG->get('cycleStyle'); ?>" /></td>
    <td>The comments will be alternately styled using the following CSS selector. You can specify as many as you want. </td>
  </tr>
  <tr class="row1">
    <td><b>Author comment css</b></td>
    <td><input class="inputbox" type="text" name="authorStyle" size="50" maxlength="50" value="<?php echo $_JC_CONFIG->get('authorStyle'); ?>" /></td>
    <td>The comments will be alternately styled using the following CSS selector. You can specify as many as you want. </td>
  </tr>
  <tr>
    <td><b>Wrap long word</b></td>
    <td><input class="inputbox" type="text" name="textWrap" size="16" maxlength="3" value="<?php echo $_JC_CONFIG->get('textWrap'); ?>" /></td>
    <td>If a word is too long, wrap it. Leave it empty to turn off text wrapping.</td>
  </tr>
  <tr class="row1">
    <td><b>Paging (Pagination)</b></td>
    <td>
    	<select name="paging" class="inputbox" id="paging">
      	<option value="0" <?php if($_JC_CONFIG->get('paging') == 0) echo "selected"; ?> > No Paging</option>
      	<option value="10" <?php if($_JC_CONFIG->get('paging') == 10) echo "selected"; ?> >10</option>
      	<option value="20"<?php if($_JC_CONFIG->get('paging') == 20) echo "selected"; ?> >20</option>
      	<option value="30"<?php if($_JC_CONFIG->get('paging') == 30) echo "selected"; ?> >30</option>
      	<option value="50"<?php if($_JC_CONFIG->get('paging') == 50) echo "selected"; ?> >50</option>
      	<option value="100"<?php if($_JC_CONFIG->get('paging') == 100) echo "selected"; ?> >100</option>
    	</select>
	</td>
    <td>&nbsp;</td>
  </tr>
  <!-- 
  <tr>
    <td><b>Alert background color</b></td>
    <td><input class="inputbox" type="text" name="alertBgColor" size="25" maxlength="8" value="<?php echo $_JC_CONFIG->get('alertBgColor'); ?>" /></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><b>Alert font color</b></td>
    <td><input class="inputbox" type="text" name="aletrFontColor" size="25" maxlength="8" value="<?php echo $_JC_CONFIG->get('aletrFontColor'); ?>" /></td>
    <td>&nbsp;</td>
  </tr>
  -->
  
  <tr class="row1">
    <td><strong>Use avatar </strong></td>
    <td><select name="gravatar" size="4" id="gravatar">
      <option value="none" <?php if($_JC_CONFIG->get('gravatar') == "none") echo "selected"; ?>> none</option>
      <option value="gravatar" <?php if($_JC_CONFIG->get('gravatar') == "gravatar") echo "selected"; ?> >Gravatar</option>
      <option value="cb"<?php if($_JC_CONFIG->get('gravatar') == "cb") echo "selected"; ?> >Community Builder</option>
      <option value="smf"<?php if($_JC_CONFIG->get('gravatar') == "smf") echo "selected"; ?> >SMF Forum Profile</option>
    </select></td>
    <td>Select which avatar to display. If you do not want to use avatar, select &quot;none&quot;, otherwise you can select <a href="http://www.gravatar.com" target="_blank">Gravatar</a>.</td>
  </tr>
  
  <tr>
    <td><b>Path to SMF forum (if required)</b></td>
    <td><input class="inputbox" type="text" name="smfPath" size="50" maxlength="500" value="<?php echo $_JC_CONFIG->get('smfPath'); ?>" /></td>
    <td>Full path to your SMF forum folder </td>
  </tr>
  <tr class="row1">
    <td width="22%"><b>Wrap SMF Profile page</b></td>
    <td width="34%"><?php echo mosHTML::yesnoRadioList( 'smfWrapped', 'class="inputbox"', $_JC_CONFIG->get('smfWrapped') ); ?></td>
    <td width="44%" valign="top"></td>
  </tr>
  <tr>
    <td><strong>Avatar size </strong></td>
    <td>width :
      <input name="gWidth" type="text" id="gWidth" value="<?php echo $_JC_CONFIG->get('gWidth'); ?>" size="4" maxlength="3"> 
      height: 
      <input name="gHeight" type="text" id="gHeight" value="<?php echo $_JC_CONFIG->get('gHeight'); ?>" size="4" maxlength="3"></td>
    <td>Size of the avatar to display </td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  
  <th colspan="3"><b>Startup options</b></h>
  <tr>
    <td><b>Enable comment area to be hidden/shown</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'slideComment', 'class="inputbox"', $_JC_CONFIG->get('slideComment') ); ?></td>
    <td>This feature will only work properly if your template did not use "quirk mode". View your page source file and make sure that &lt;!DOCTYPE appear on the first line. 
    If not, do not enable this feature as it will fails in Internet Explorer although it works well with FireFox. </td>
  </tr>
  <tr class="row1">
    <td><b>Start with comments area hidden</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'startAreaHidden', 'class="inputbox"', $_JC_CONFIG->get('startAreaHidden') ); ?></td>
    <td></td>
  </tr>
  <tr>
    <td><b>Enable input area to be hidden/shown</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'slideForm', 'class="inputbox"', $_JC_CONFIG->get('slideForm') ); ?></td>
    <td>This feature will only work properly if your template did not use "quirk mode". View your page source file and make sure that &lt;!DOCTYPE appear on the first line. 
    If not, do not enable this feature as it will fails in Internet Explorer although it works well with FireFox</td>
  </tr>
  <tr class="row1">
    <td><b>Start with comment form hidden</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'startFormHidden', 'class="inputbox"', $_JC_CONFIG->get('startFormHidden') ); ?></td>
    <td></td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <th colspan="3"><b>Display format</b></h>
  <tr>
    <td><b>Date format</b></td>
    <td><input class="inputbox" type="text" name="dateFormat" size="48" maxlength="48" value="<?php echo $_JC_CONFIG->get('dateFormat'); ?>" /></td>
    <td>&nbsp;You can use PHP formatting strings. Please refer to PHP documentation <a target="_blank" href="http://de.php.net/strftime">here</a>. Leave it empty to use default formatting.
    </td>
  </tr>
    <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <th colspan="3"><b>&quot;Read More&quot; integration</b></h>
  <tr>
    <td><b>Show comment count in front page</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'showCommentCount', 'class="inputbox"', $_JC_CONFIG->get('showCommentCount') ); ?></td>
    <td>Select "yes" to show number of comment, along with link to comment area in front page and blog view.</td>
  </tr>
  <tr class="row1">
    <td><b>Show hit count </b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'showHitCount', 'class="inputbox"', $_JC_CONFIG->get('showHitCount') ); ?></td>
    <td>Select "yes" to show number of hits for the particular content</td>
  </tr>
  <tr>
    <td><b>Use Jom Comment's "Read more"</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'useReadMore', 'class="inputbox"', $_JC_CONFIG->get('useReadMore') ); ?></td>
    <td>Select "Yes" to use Jom Comment's "Read more" tag instead of Joomla's default "read more" link.</td>
  </tr>
  <tr class="row1">
    <td><b>Only show &quot;read more&quot; if necessary</b></td>
    <td><?php echo mosHTML::yesnoRadioList( 'useSelectiveReadMore', 'class="inputbox"', $_JC_CONFIG->get('useSelectiveReadMore') ); ?></td>
    <td>If you select yes, "Read more" will only appear in articles that needs it. Select no to show "Read more" in all articles.</td>
  </tr>
    <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
</table>

    <?php

	$tabs->endTab();
	$tabs->endPane();
?>
  <input type="hidden" name="option" value="<?php echo $option; ?>">
  <input type="hidden" name="task" value="savesettings">
  <input type="hidden" name="boxchecked" value="0">
</form>
</div>
