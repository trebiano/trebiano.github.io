<?php
ob_start();
defined('_VALID_MOS') or die('Direct Access to this location is not allowed.');
global $mosConfig_absolute_path, $task, $_JC_CONFIG;
global $jcPatchClass;
$jcPatchClass = array ();

require_once ($mosConfig_absolute_path . "/administrator/components/com_jomcomment/class.jomcomment.php");
require_once ($mosConfig_absolute_path . "/administrator/components/com_jomcomment/admin.jomcomment.html.php");
require_once ($mosConfig_absolute_path . "/components/com_jomcomment/jomcomment.php");
include_once ($mosConfig_absolute_path . "/mambots/system/pc_includes/ajax.php");
include_once ($mosConfig_absolute_path . "/mambots/system/pc_includes/template.php");
require_once ($mosConfig_absolute_path . "/administrator/components/com_jomcomment/patch.jomcomment.php");
$patchFiles = mosReadDirectory($mosConfig_absolute_path . "/administrator/components/com_jomcomment/patch", "php");
foreach ($patchFiles as $p) {
	require_once ($mosConfig_absolute_path . "/administrator/components/com_jomcomment/patch/" . $p);
}
$cid = mosGetParam($_REQUEST, 'cid', 0);
$task = mosGetParam($_POST, 'task', '');

if (empty ($task))
	$task = mosGetParam($_GET, 'task', 'comments');

switch ($task) {
	case 'xajax' :
		break;
	case 'exportEmail' :
		jcExportEmail();
		break;
	case 'hacks' :
		ob_start();
		showAjaxedAdmin();
		$panel = ob_get_contents();
		ob_end_clean();
		ob_start();
		showAvailableHacks();
		$content = ob_get_contents();
		ob_end_clean();
		$content = str_replace("{CONTENT}", $content, $panel);
		echo $content;
		break;
	case "import" :
		ob_start();
		showAjaxedAdmin();
		$panel = ob_get_contents();
		ob_end_clean();
		ob_start();
		importAko($option);
		$content = ob_get_contents();
		ob_end_clean();
		$content = str_replace("{CONTENT}", $content, $panel);
		echo $content;
		break;
	case "save" :
		saveComment($option);
		break;
	case "maintd" :
		ob_start();
		showAjaxedAdmin();
		$panel = ob_get_contents();
		ob_end_clean();
		ob_start();
		showMaintd();
		$content = ob_get_contents();
		ob_end_clean();
		$content = str_replace("{CONTENT}", $content, $panel);
		echo $content;
		break;
	case "remove" :
		removeComments($cid, $option);
		break;
	case "publish" :
		publishComments($cid, 1, $option);
		break;
	case "unpublish" :
		publishComments($cid, 0, $option);
		break;
	case "publish_tb" :
		publishTrackbacks($cid, 1, $option);
		break;
	case "unpublish_tb" :
		publishTrackbacks($cid, 0, $option);
		break;
	case "remove_tb" :
		removeTrackbacks($cid, $option);
		break;
	case "config" :
		ob_start();
		showAjaxedAdmin();
		$panel = ob_get_contents();
		ob_end_clean();
		ob_start();
		showConfig($option);
		$content = ob_get_contents();
		ob_end_clean();
		$content = str_replace("{CONTENT}", $content, $panel);
		echo $content;
		break;
	case "editLanguage" :
		ob_start();
		showAjaxedAdmin();
		$panel = ob_get_contents();
		ob_end_clean();
		ob_start();
		editLanguage("xxx");
		$content = ob_get_contents();
		ob_end_clean();
		$content = str_replace("{CONTENT}", $content, $panel);
		echo $content;
		break;
	case "savesettings" :
		saveConfig($option);
		break;
	case "stats" :
		ob_start();
		showAjaxedAdmin();
		$panel = ob_get_contents();
		ob_end_clean();
		ob_start();
		showStatistics();
		$content = ob_get_contents();
		ob_end_clean();
		$content = str_replace("{CONTENT}", $content, $panel);
		echo $content;
		break;
	case "about" :
		ob_start();
		showAjaxedAdmin();
		$panel = ob_get_contents();
		ob_end_clean();
		ob_start();
		showAbout();
		$content = ob_get_contents();
		ob_end_clean();
		$content = str_replace("{CONTENT}", $content, $panel);
		echo $content;
		break;
	case "support" :
		ob_start();
		showAjaxedAdmin();
		$panel = ob_get_contents();
		ob_end_clean();
		ob_start();
		showSupport();
		$content = ob_get_contents();
		ob_end_clean();
		$content = str_replace("{CONTENT}", $content, $panel);
		echo $content;
		break;
	case "license" :
		ob_start();
		showAjaxedAdmin();
		$panel = ob_get_contents();
		ob_end_clean();
		ob_start();
		showLicense();
		$content = ob_get_contents();
		ob_end_clean();
		$content = str_replace("{CONTENT}", $content, $panel);
		echo $content;
		break;
	case "trackbacks" :
		ob_start();
		showAjaxedAdmin();
		$panel = ob_get_contents();
		ob_end_clean();
		ob_start();
		showTrackbacks($option);
		$content = ob_get_contents();
		ob_end_clean();
		$content = str_replace("{CONTENT}", $content, $panel);
		echo $content;
		break;
	case "comments" :
	default :
		ob_start();
		showAjaxedAdmin();
		$panel = ob_get_contents();
		ob_end_clean();
		ob_start();
		showComments($option);
		$content = ob_get_contents();
		ob_end_clean();
		$content = str_replace("{CONTENT}", $content, $panel);
		echo $content;
		break;
}

function editLanguage() {
	global $mosConfig_absolute_path;
	$file_list = mosReadDirectory($mosConfig_absolute_path . "/components/com_jomcomment/languages", ".php");
	$options = "";
	foreach ($file_list as $file) {
		$options .= "<option value=\"$file\">$file</option>";
	}
	HTML_comment :: showLanguageEdit($options);
}

function jcxDoPatch($com, $action) {
	global $jcPatchClass;
	$result = "";
	eval ('$patch = new ' . $jcPatchClass[$com] . '();');
	$result = $patch->action($action);
	return $result;
}

function modifyText(& $item, $key) {
	$item->comment = transformDbText($item->comment);
}

function jcxLoadLangFile($fileName) {
	global $database, $mosConfig_absolute_path;
	while (@ ob_end_clean());
	ob_start();
	$filename = $mosConfig_absolute_path . "/components/com_jomcomment/languages/" . $fileName;
	$handle = fopen($filename, "r");
	$contents = fread($handle, filesize($filename));
	fclose($handle);
	$pattern = "'<?" . "php(.*)\?" . ">'s";
	preg_match($pattern, $contents, $matches);
	$contents = @ $matches[1];
	$contents = trim($contents);
	$objResponse = new JAXResponse();
	$objResponse->addAssign('editLangTextArea', 'value', $contents);
	$objResponse->addAssign('currentFile', 'value', $fileName);
	$objResponse->addAssign('ajaxInfo', 'innerHTML', $fileName . " loaded...");
	return $objResponse->sendResponse();
}
function jcxTogglePublish($id) {
	global $database;
	while (@ ob_end_clean());
	ob_start();
	$database->setQuery("SELECT published FROM #__jomcomment WHERE id=$id");
	$publish = $database->loadResult();
	$publish = intval(!($publish));
	$database->setQuery("UPDATE #__jomcomment SET published='$publish' WHERE id=$id");
	$database->query();
	$objResponse = new JAXResponse();
	if ($publish) {
		$objResponse->addAssign('pubImg' . $id, 'src', 'images/publish_g.png');
		$d['id'] = $id;
	} else {
		$objResponse->addAssign('pubImg' . $id, 'src', 'images/publish_x.png');
		$d['id'] = $id;
	}
	return $objResponse->sendResponse();
}
function jcxToggleTrackbackPublish($id) {
	global $database;
	while (@ ob_end_clean());
	ob_start();
	$database->setQuery("SELECT published FROM #__jomcomment_tb WHERE id=$id");
	$publish = $database->loadResult();
	$publish = intval(!($publish));
	$database->setQuery("UPDATE #__jomcomment_tb SET published='$publish' WHERE id=$id");
	$database->query();
	$objResponse = new JAXResponse();
	if ($publish) {
		$objResponse->addAssign('pubImg' . $id, 'src', 'images/publish_g.png');
	} else {
		$objResponse->addAssign('pubImg' . $id, 'src', 'images/publish_x.png');
	}
	return $objResponse->sendResponse();
}
function jcConvertTitleToUtf8(& $str) {
	if (function_exists('mb_convert_encoding')) {
		$iso = explode('=', _ISO);
		$source = mb_convert_encoding($str->text, "UTF-8", "$iso[1], auto");
		$str->text = $source;
	} else
		$str->text = transformDbText($str->text);
}
function jcxEditComment($commentid) {
	global $database, $_JC_CONFIG;
	while (@ ob_end_clean());
	ob_start();
	$obj = null;
	$database->setQuery("SELECT * FROM #__jomcomment WHERE id=$commentid LIMIT 1");
	$comment = $database->loadAssocList();
	$text ='
	<div id="liveEditForm-{id}">
	  <table width="80%" border="0" align="center" cellpadding="4" cellspacing="1" class="liveEditForm">
	    <tbody>
	    <!-- 
	    <tr>
	      <td align="right"><strong>Published:</strong></td>
	      <td>{published}
	        <label for="published"></label></td>
	    </tr>
	    -->
	    <tr>
	      <td align="right" width="20%"><strong>Name:</strong></td>
	      <td width="80%"><input name="name-edit-{id}" id="name-edit-{id}" type="text" class="inputbox" style="background-color: rgb(255, 255, 160);" value="{name}" size="50" maxlength="30">      </td>
	    </tr>
	
	    <tr>
	      <td align="right" valign="top"><strong>Email:</strong></td>
	      <td><input style="background-color: rgb(255, 255, 160);" name="email-edit-{id}" class="inputbox" id="email-edit-{id}" value="{email}" size="50" maxlength="30" type="text"></td>
	    </tr>
	    <tr>
	      <td align="right" valign="top"><strong>Website:</strong></td>
	      <td><input name="website-edit-{id}" class="inputbox" id="website-edit-{id}" value="{website}" size="50" maxlength="30" type="text"></td>
	    </tr>
	
	    <tr>
	      <td align="right" valign="top"><strong>Content Item:</strong></td>
	      <td>{contentList}</td>
	    </tr>
	    <tr>
	      <td align="right" valign="top"><strong>Title:</strong></td>
	      <td><input name="title-edit-{id}" id="title-edit-{id}" type="text" class="inputbox" value="{title}" size="50" maxlength="50">      </td>
	    </tr>
	    <tr>
	      <td align="right" valign="top"><strong>Comment:</strong></td>
	
	      <td><textarea class="inputbox" cols="50" rows="5" name="comment-edit-{id}" id="comment-edit-{id}">{comment}</textarea>      </td>
	    </tr>
	    <tr>
	      <td align="right" width="20%"><strong>Date:</strong></td>
	      <td width="80%"><input name="date-edit-{id}" id="date-edit-{id}" type="text" class="inputbox" style="background-color: rgb(255, 255, 160);" value="{date}" size="50" maxlength="30">      </td>
	    </tr>
	    <tr>
	      <td align="right" valign="top">
	      <input id="id-edit-{id}" name="id-edit-{id}" value="{id}" type="hidden">
	      </td>
	    <td>
	        <input type="button" name="Button" value="Save" class="CommonTextButtonSmall" onClick="jax.call(\'jomcomment\', \'jcxSaveComment\', jc_getEditFormValues(\'{id}\'));">
	        <input name="Discard &amp; Close" type="button" class="CommonTextButtonSmall" id="Discard &amp; Close" value="Discard &amp; Close" onClick="jc_closeEdit(\'{id}\');">
	        &nbsp;
	        <!--
	        <input type="button" name="Button" value="Spam" class="CommonTextButtonSmall" onClick="jax.call(\'jomcomment\', \'jcxTrainFilter\', jc_getEditFormValues(\'{id}\'), \'spam\');">
	        <input type="button" name="Button" value="Non Spam" class="CommonTextButtonSmall" onClick="jax.call(\'jomcomment\', \'jcxTrainFilter\',jc_getEditFormValues(\'{id}\'), \'nonspam\' );">
	        -->
	    </td>
	    </tr>
	  </tbody></table>
	</div>
	    '; 
	$publish = mosHTML :: yesnoRadioList('published', ' ', intval($comment[0]['published']));
$comment[0]['comment'] = str_replace("<br />", '\n', stripslashes($comment[0]['comment']));
$comment[0]['comment'] = str_replace("<br/>", '\n', stripslashes($comment[0]['comment']));
$comment[0]['comment'] = str_replace("</br>", '\n', stripslashes($comment[0]['comment']));
$text = str_replace("{published}", $publish, $text);
$text = str_replace("{contentList}", $clist, $text);
$text = str_replace("{date}", stripslashes($comment[0]['date']), $text);
$text = str_replace("{name}", stripslashes($comment[0]['name']), $text);
$text = str_replace("{comment}", stripslashes($comment[0]['comment']), $text);
$text = str_replace("{title}", stripslashes($comment[0]['title']), $text);
$text = str_replace("{email}", $comment[0]['email'], $text);
$text = str_replace("{website}", $comment[0]['website'], $text);
$text = str_replace("{id}", $comment[0]['id'], $text);
$tpl = & new AzrulJXTemplate();
foreach ($comment[0] as $key => $val) {
	$tpl->set($key, $val);
}
$database->setQuery("SELECT title FROM #__content WHERE id='" . $comment[0]['contentid'] . "'");
$tpl->set('content_title', $database->loadResult());
$tpl->set('contentList', $clist);
$tpl->set('publish', $publish);
$html = $tpl->fetch(JC_ADMIN_COM_PATH . 'templates/edit_comment.tpl.html');
$objResponse = new JAXResponse();
$objResponse->addScriptCall("showFloatingDialog", $html);
return $objResponse->sendResponse();
}
function jcxSaveComment($xajaxArgs) {
	global $database;
	while (@ ob_end_clean());
	ob_start();
	$row = new mosJomcomment($database);
	$commentid = $xajaxArgs['id'];
	$row->bind($xajaxArgs);
	$row->store();
	$row->updateOrder("contentid='$row->contentid'");
	$newrow = new mosJomcomment($database);
	$newrow->load($commentid);
	$nlSearch = array (
		"\n",
		"\r"
	);
	$nlReplace = array (
		" ",
		" "
	);
	$newrow->comment = str_replace($nlSearch, $nlReplace, $newrow->comment);
	$newrow->comment = transformDbText($row->comment);
	if (strlen($newrow->comment) > 300) {
		$newrow->comment = stripslashes(substr($newrow->comment, 0, 300 - 3));
		$newrow->comment .= "...";
	}
	$newrow->comment = strip_tags($newrow->comment);
	$con = new mosContent($database);
	$con->load($newrow->contentid);
	$objResponse = new JAXResponse();
	$objResponse->addScriptCall("$('popupWindowContainer').setStyle", 'visibility', 'hidden');
	$objResponse->addAssign("comment-" . $commentid, 'innerHTML', $newrow->comment);
	$objResponse->addAssign("date-" . $commentid, 'innerHTML', $newrow->date);
	global $mosConfig_cachepath;
	$file_list = mosReadDirectory($mosConfig_cachepath, "");
	foreach ($file_list as $val) {
		if (strstr($val, "cache_")) {
			@ unlink($mosConfig_cachepath . "/" . $val);
		}
	}
	return $objResponse->sendResponse();
}
function jcxBanUserName($name) {
	global $_JC_CONFIG;
	$_JC_CONFIG->addBlockedUser($name);
	$objResponse = new JAXResponse();
	$objResponse->addScriptCall("alert", "$name blocked");
	return $objResponse->sendResponse();
}
function jcxBanUserIP($ip) {
	global $_JC_CONFIG;
	$_JC_CONFIG->addBlockedIP($ip);
	$objResponse = new JAXResponse();
	$objResponse->addScriptCall("alert", "$ip IP blocked");
	return $objResponse->sendResponse();
}
function jcxSaveLanguage($content, $fileName) {
	global $database, $mosConfig_absolute_path;
	while (@ ob_end_clean());
	$content = "<?php
" . $content . " ? " . " > ";
	$content = stripslashes($content);
	$filename = $mosConfig_absolute_path . " / components / com_jomcomment / languages / " . $fileName;
	$handle = fopen($filename, " w ");
	fwrite($handle, ($content));
	fclose($handle);
	$objResponse = new JAXResponse();
	$objResponse->addAssign(" ajaxInfo ", 'innerHTML', $fileName . " saved . . . ");
	return $objResponse->sendResponse();
}
function jcExportEmail(){
	global $database, $mosConfig_absolute_path;
	include_once($mosConfig_absolute_path . "/components/com_jomcomment/includes/csv/csv.php");
	$database->setQuery("SELECT DISTINCT email, name FROM #__jomcomment");
	$rows = $database->loadObjectList();
	
	//$csv =  new CSVHandler('parish_only.csv', ',', 'pnumber');
	//$result = $csv->ReadCSV();
	
	if($rows){
		@ob_clean();
		header('Content-type: text/csv'); 
		header('Content-Disposition: attachment; filename="visitors.csv"');

		foreach($rows as $row){
			echo "{$row->email},{$row->name}\n";
		}
		exit;
	}

	//$objResponse = new JAXResponse();
	//$objResponse->addAlert($response);
	
	//return $objResponse->sendResponse();
}


function jcxTrainFilterTest($id){
	return jcxTrainTrackbackFilterTest($id, false);
}

function jcxTrainTrackbackFilterTest($id, $isTrackback=true){
	global $database;
	
	if($isTrackback)
		$database->setQuery("SELECT excerpt, url FROM #__jomcomment_tb WHERE id=$id");
	else
		$database->setQuery("SELECT comment FROM #__jomcomment WHERE id=$id");
		
	$comment = $database->loadRow();
	$document = $comment[0] . " " . $comment[1] ;

	$data = "action=cat&type=comment&version=2&document=" . urlencode($document);
	$response = post("filter0.azrul.com/index.php", $data);
	$objResponse = new JAXResponse();
	$objResponse->addAlert($response);
	
	return $objResponse->sendResponse();
}

function jcxTrainTrackbackFilter($contentid, $cat, $quite = true) {
	return jcxTrainFilter($contentid, $cat, $quite, true);
}
/**
 * Send the filter setting to our centralize server
 */
function jcxTrainFilter($contentid, $cat, $quite = true, $trackback= false) {
	global $database, $mosConfig_absolute_path, $mosConfig_live_site, $mosConfig_lang;

	$document = "";
	$docid = "$mosConfig_live_site-$contentid";
	
	if($trackback){
		$database->setQuery("SELECT excerpt, url FROM #__jomcomment_tb WHERE id=$contentid");
		$docid .= "-tb";
		
		$comment = $database->loadRow();
		$document = $comment[0] . " " . $comment[1] ;
	
	} else {
		$database->setQuery("SELECT comment FROM #__jomcomment WHERE id=$contentid");
		$docid .= "-comment";
		
		$comment = $database->loadResult();
		$document = $comment;
	}
	
	

	if (true) {

		while (@ ob_end_clean());
		ob_start();
		$data = "action=train&server=$docid&cat=$cat&document=" . urlencode($document) . "&version=2&lang=$mosConfig_lang";
		$response = post("filter0.azrul.com/index.php", $data);
		$objResponse = new JAXResponse();
		$objResponse->addAlert($response);
		$objResponse->addAlert("Filter Trained");
		return $objResponse->sendResponse();
	} else {
		ob_start();
		$data = "action=train&docid=$mosConfig_live_site-$contentid&cat=$cat&document=" . urlencode($document) . "&version=2&lang=$mosConfig_lang";
		$response = post("filter0.azrul.com/index.php", $data);
		ob_end_clean();

	}
}

function post($host, $query, $others = '') {

	if(function_exists('curl_init')){
		$ch = curl_init();
		curl_setopt ($ch, CURLOPT_URL, "http://" .$host . "?". $query);
		curl_setopt ($ch, CURLOPT_HEADER, 0);
		ob_start();
		curl_exec ($ch);
		curl_close ($ch);
		$string = ob_get_contents();
		ob_end_clean();
		return $string;
	}
	
	if(ini_get('allow_url_fopen') == 1){
		
		$dh = fopen("http://". $host . "?". $query,'r');
		$result = fread($dh,8192);                                                                                                                   
		return $result;
	}

	/////////////////////////
	$path = explode('/', $host);
	$host = $path[0];
	$r = "";
	unset ($path[0]);
	$path = '/' . (implode('/', $path));
	$post = "POST $path HTTP/1.0\r\nHost: $host\r\nContent-type: application/x-www-form-urlencoded\r\n${others}User-Agent: Mozilla 4.0\r\nContent-length: " . strlen($query) . "\r\nConnection: close\r\n\r\n$query";
	$h = fsockopen($host, 80, $errno, $errstr, 7);
	if ($h) {
		fwrite($h, $post);
		for ($a = 0, $r = ''; !$a;) {
			$b = fread($h, 8192);
			$r .= $b;
			$a = (($b == '') ? 1 : 0);
		}
		fclose($h);
	}
	return $r;
}

/**
 * Show the comment listing page
 */ 
function showComments($option) {
	global $database, $mainframe, $mosConfig_live_site;
	
	$database->setQuery("SELECT distinct `option` FROM #__jomcomment");
    $results = $database->loadObjectList();
    $default_com = 'com_content';
	if(count($results) == 1){
    	$default_com = $results[0]->option;
	}
	
	$limitOption = mosGetParam($_GET, 'limitOption', $default_com);
	
	
	$limit = $mainframe->getUserStateFromRequest("viewlistlimit", 'limit', 10);
	$limitstart = $mainframe->getUserStateFromRequest("view{$option}limitstart", 'limitstart', 0);
	$search = $mainframe->getUserStateFromRequest("search{$option}", 'search', '');
	$search = $database->getEscaped(trim(strtolower($search)));
	
	$searchContent = $mainframe->getUserStateFromRequest("searchContent{$option}", 'searchContent', '');
	$searchContent = $database->getEscaped(trim(strtolower($searchContent)));
 	

	$where = array ();
	
	// Seach for comment with the given string
	if ($search) {
		$where[] = "LOWER(comment) LIKE '%$search%'";
	}
	
	$where[] = "`option`='$limitOption' ";
	
	// search for comment with the given content. Only the first content that
	// matches is displayed	
	if($searchContent){
		$database->setQuery("SELECT id FROM #__content WHERE `title` LIKE '%$searchContent%'");
		$contentid = $database->loadResult();
		if($contentid != 0){
			$where[] = " `contentid`=$contentid ";
			$where[] = " `option`='$limitOption' ";
		}
	}

	$database->setQuery("SELECT count(*) FROM #__jomcomment AS a" . (count($where) ? "\nWHERE " . implode(' AND ', $where) : ""));
	$total = $database->loadResult();
	include_once ("includes/pageNavigation.php");
	$pageNav = new mosPageNav($total, $limitstart, $limit);

	$database->setQuery("SELECT * FROM #__jomcomment" . (count($where) ? "\nWHERE " . implode(' AND ', $where) : "") . "\nORDER BY id DESC" . "\nLIMIT $pageNav->limitstart,$pageNav->limit");
	$rows = $database->loadObjectList();
	array_walk($rows, 'modifyText');
	if ($database->getErrorNum()) {
		echo $database->stderr();
		return false;
	}

	HTML_comment :: showComments($option, $rows, $search, $pageNav, $searchContent);
}


/**
 * Show the trackback list page
 */ 
function showTrackbacks($option) {
	global $database, $mainframe, $mosConfig_live_site;

	$limit = $mainframe->getUserStateFromRequest("viewlistlimit", 'limit', 10);
	$limitstart = $mainframe->getUserStateFromRequest("view{$option}limitstart", 'limitstart', 0);
	$search = $mainframe->getUserStateFromRequest("search{$option}", 'search', '');
	$search = $database->getEscaped(trim(strtolower($search)));


 	$searchContent = $mainframe->getUserStateFromRequest("searchContent{$option}", 'searchContent', '');
 	$searchContent = $database->getEscaped(trim(strtolower($searchContent)));
 	
	$where = array ();
	if ($search) {
		$where[] = "LOWER(excerpt) LIKE '%$search%'";
	}
	
	// search for comment with the given content. Only the first content that
	// matches is displayed	
	if($searchContent){
		$database->setQuery("SELECT id FROM #__content WHERE `title` LIKE '%$searchContent%'");
		$contentid = $database->loadResult();
		if($contentid != 0){
			$where[] = " `contentid`=$contentid ";
		}
	}

	$database->setQuery("SELECT count(*) FROM #__jomcomment_tb AS a" . (count($where) ? "\nWHERE " . implode(' AND ', $where) : ""));
	$total = $database->loadResult();
	include_once ("includes/pageNavigation.php");
	$pageNav = new mosPageNav($total, $limitstart, $limit);

	$database->setQuery("SELECT * FROM #__jomcomment_tb" . (count($where) ? "\nWHERE " . implode(' AND ', $where) : "") . "\nORDER BY id DESC" . "\nLIMIT $pageNav->limitstart,$pageNav->limit");
	$rows = $database->loadObjectList();
	//array_walk($rows, 'modifyText');
	if ($database->getErrorNum()) {
		echo $database->stderr();
		return false;
	}

	HTML_trackbacks :: showTrackbacks($option, $rows, $search, $pageNav, $searchContent);
}


/**
 * 
 */ 
function publishComments($cid = null, $publish = 1, $option) {
	global $database;
	if (!is_array($cid) || count($cid) < 1) {
		$action = $publish ? 'publish' : 'unpublish';
		echo "<script> alert('Select an item to $action'); window.history.go(-1);</script>\n";
		exit;
	}
	$cids = implode(',', $cid);
	$database->setQuery("UPDATE #__jomcomment SET published='$publish' WHERE id IN ($cids)");
	if (!$database->query()) {
		echo "<script> alert('" . $database->getErrorMsg() . "'); window.history.go(-1); </script>\n";
		exit ();
	}
	
	# Clear the cache, otherwise it won't show after refresh
	global $mosConfig_cachepath;		
	$file_list = mosReadDirectory($mosConfig_cachepath, "");
	foreach ($file_list as $val) {
		if (strstr($val, "cache_")){
			@unlink($mosConfig_cachepath . "/" . $val);
		}
	}
	
	mosRedirect("index2.php?option=$option&task=comments");
}

/**
 *
 */ 
function publishTrackbacks($cid = null, $publish = 1, $option) {
	global $database;
	if (!is_array($cid) || count($cid) < 1) {
		$action = $publish ? 'publish' : 'unpublish';
		echo "<script> alert('Select an item to $action'); window.history.go(-1);</script>\n";
		exit;
	}
	$cids = implode(',', $cid);
	$database->setQuery("UPDATE #__jomcomment_tb SET published='$publish' WHERE id IN ($cids)");
	if (!$database->query()) {
		echo "<script> alert('" . $database->getErrorMsg() . "'); window.history.go(-1); </script>\n";
		exit ();
	}
	
		
	mosRedirect("index2.php?option=$option&task=trackbacks");
}


function showMaintd(){
	global $mosConfig_cachepath, $database;
	
	if(isset($_POST) && isset($_POST['maintd'])){
		if(isset($_POST['maintd']) && $_POST['maintd'] == 'clearcache'){
			$file_list = mosReadDirectory($mosConfig_cachepath, "");
			foreach ($file_list as $val) {
				if (strstr($val, "cache_")){
					@unlink($mosConfig_cachepath . "/" . $val);
				}
			}
			
			echo "<h3>Cache cleared...</h3>";
		}
		
		if(isset($_POST['maintd']) && $_POST['maintd'] == 'clearunpublished'){
			$database->setQuery("DELETE FROM #__jomcomment WHERE published=0");
			$database->query();
			
			$database->setQuery("DELETE FROM #__jomcomment_tb WHERE published=0");
			$database->query();
			
			echo "<h3>Unpublished items deleted...</h3>";
		}
	}
	
?>

<table width="860" border="0" cellspacing="4" cellpadding="4">
    <tr>
        <td width="558"><strong>Clear all Jom Comment cache.<br />
        </strong>Jom Comment cache the generated page to significantly increase the loading performance. This cache is independent of Joomla cache and are automatically cleared at a specific interval. If you want, you can force the cache to be cleared here </td>
        <td width="274"><form id="form1" name="form1" method="post" action="">
            <input type="submit" name="Submit"  class="CommonTextButtonSmall" value="Clear Jom Comment Cache" />
            <input name="maintd" type="hidden" id="maintd" value="clearcache" />
        </form>        </td>
    </tr>
    <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
    </tr>
    <tr>
        <td><strong>Removed unpublished comments and trackbacks</strong><br />
        You can delete all unpublished items from Jom Comment database to make the database smaller.
        </td>
        <td><form id="form1" name="form1" method="post" action="">
            <input type="submit" name="Submit"  class="CommonTextButtonSmall" value="Delete unpublished items" />
            <input name="maintd" type="hidden" id="maintd" value="clearunpublished" /></td>
    </tr>
</table>

	<?php } 
	function showAbout() { HTML_comment :: showAbout(); } function showSupport() { HTML_comment :: showSupport(); } function showLicense() { HTML_comment :: showLicense(); } 
	
	function importJoomlaComment() { 
		global $database, $mosConfig_dbprefix; 
		$query = "INSERT INTO #__jomcomment
	                (contentid, `option`, ip, name, title, comment, date, published)
	              SELECT
	                contentid, 'com_content', ip, name, title, comment,date,published
	              FROM  #__comment"; 
				$database->setQuery($query); 
	            $database->query(); 
				$numImported = $database->getAffectedRows(); 
				echo "Finished... "; echo $numImported . " comments imported"; 
	} 
	
	function importAkoData() { 
		global $database, $mosConfig_dbprefix; 
		$tname = array ( "#__akocomment" ); 
		$fields = @ $database->getTableFields($tname); 
		if (!empty ($fields)) { 
			$prefix = "#__akocomment"; $addwhere = ""; 
			if (isset ($_REQUEST['nounpublished']) && (@ $_REQUEST['nounpublished'])) { 
				$addwhere = " AND published=1 "; 
			} 
			$fieldURL = array_key_exists("url", $fields[$prefix]); 
			$fieldWeb = array_key_exists("web", $fields[$prefix]); 
			$fieldEmail = array_key_exists("email", $fields[$prefix]); 
			$insertMore = ""; 
			$selectMore = ""; 
			if ($fieldURL) { 
				$insertMore .= ", website"; 
				$selectMore .= ", url"; 
			} else if ($fieldWeb) { 
				$insertMore .= ", website"; $selectMore .= ", web"; } 
				
				if ($fieldEmail) { 
					$insertMore .= ", email"; 
					$selectMore .= ", email"; 
				} 
				$query = sprintf("
		        INSERT INTO #__jomcomment
		        (contentid, `option`, ip, name, title, comment, date, published %s)
		        SELECT contentid, 'com_content', ip, name, title, comment,date,published %s
		        from #__akocomment where 1 %s;", $insertMore, $selectMore, $addwhere); 
				$database->setQuery($query); 
				$database->query(); 
				$database->getQuery(); 
				$numImported = $database->getAffectedRows(); 
				echo "Finished... "; 
				echo $numImported . " comments imported"; 
				} else { echo "No AkoCOmment data detected"; } } 
				function importAko($option) { echo '
	        <table cellpadding="4" cellspacing="0" border="0" width="100%">
	        <tr>
	            <td width="100%" class="sectionname">
	                <img src="components/com_jomcomment/logo.png">
	            </td>
	        </tr>
	        </table>'; global $database, $mosConfig_dbprefix; 
			if (!empty ($_REQUEST['confirm'])) { 
				if ($_REQUEST['from'] == "joomlacomment") { 
					importJoomlaComment(); 
				} else if ($_REQUEST['from'] == "ako") { 
					importAkoData(); 
				} else if ($_REQUEST['from'] == "combomax") { 
					$tname = array ( "#__combomax" ); 
					$fields = $database->getTableFields($tname); 
					if (!empty ($fields)) { 
						$prefix = "#__combomax"; 
						if (array_key_exists("imported", $fields[$prefix])) { 
							echo "<p><div align=\"left\">Database records has been imported.</div></p>"; 
							return; 
						} 
						$addwhere = ""; 
						
						if (isset ($_REQUEST['nounpublished']) && (@ $_REQUEST['nounpublished'])) { 
							$addwhere = " AND approved=1 "; 
						} 
						
						$fieldURL = array_key_exists("url", $fields[$prefix]); 
						$fieldEmail = array_key_exists("email", $fields[$prefix]); 
						$insertMore = ""; $selectMore = ""; 
						if ($fieldURL) { 
							$insertMore .= ", website"; $selectMore .= ", url"; 
			} else if ($fieldWeb) { 
				$insertMore .= ", website"; 
				$selectMore .= ", web"; 
			} 
			if ($fieldEmail) { 
				$insertMore .= ", email"; $selectMore .= ", email"; 
			} 
			$query = "ALTER TABLE #__combomax ADD imported tinyint null;"; 
			$database->setQuery($query); 
			$database->query(); $query = sprintf("
						                INSERT INTO #__jomcomment
						                (contentid, `option`, ip, name, title, comment, date, published %s)
						                SELECT contentid, 'com_content', ip, name, '...', comment,date,approved %s
						                from #__combomax where imported IS null %s;", $insertMore, $selectMore, $addwhere); 
										$database->setQuery($query); $database->query(); 
										$numImported = $database->getAffectedRows(); 
										$query = "UPDATE #__akocomment SET imported=1;"; 
										$database->setQuery($query); $database->query(); 
										echo "Finished... "; echo $numImported . " comments imported"; 
										} else { 
											echo "No ComboMax data detected"; 
										} 
									} else { 
										$tname = array ( "#__content_comments" ); 
										$fields = $database->getTableFields($tname); 
										if (!empty ($fields)) { 
											$prefix = "#__content_comments"; 
												if (array_key_exists("imported", $fields[$prefix])) { 
													echo "<p><div align=\"left\">Database records has been imported.</div></p>"; 
													return; 
												} 
												$addwhere = ""; 
												if (isset ($_REQUEST['nounpublished']) && (@ $_REQUEST['nounpublished'])) { 
													$addwhere = " AND `published`=1 "; 
												} 
												
												$fieldURL = array_key_exists("homepage", $fields[$prefix]); 
												$fieldEmail = array_key_exists("email", $fields[$prefix]); 
												$insertMore = ""; $selectMore = ""; 
												if ($fieldURL) { 
													$insertMore .= ", website"; $selectMore .= ", homepage"; 
												} 
												
												if ($fieldEmail) { 
													$insertMore .= ", email"; $selectMore .= ", email"; 
												} 
												
												$query = "ALTER TABLE #__content_comments ADD imported tinyint null;"; 
												$database->setQuery($query); 
												$database->query(); 
												$query = sprintf("
						                INSERT INTO #__jomcomment
						                (contentid, `option`, name, title, comment, date, published %s)
						                SELECT articleid, 'com_content', name, '...', entry, NOW(),approved %s
						                from #__content_comments where imported IS null %s;", $insertMore, $selectMore, $addwhere); 
						                
										$database->setQuery($query); 
										$database->query(); 
										$numImported = $database->getAffectedRows(); 
										$query = "UPDATE #__content_comments SET imported=1;"; 
										$database->setQuery($query); 
										$database->query(); 
										echo "Finished... "; 
										echo $numImported . " comments imported"; 
										} else { echo "No MosCom data detected"; } } 
										} else { ?><a name="ako"></a>
    <table width="860px" border="0" cellspacing="0" cellpadding="0"  class="mytable" >
<th>Import from AkoComment</th>
  <tr>
    <td><form name="formAko" method="post" action="">
      <p></p>
      <p>We will now attempt to import existing AkoComment data into Jom Comment. No data will be lost in this process. Click &quot;Import Now&quot;to proceed.           </p>
      <p>
        <input name="nounpublished" type="checkbox" id="nounpublished" value="true">
        Do not import unpublished comments </p>
      <p><input type="hidden" name="from" id="from" value="ako" />
        <input type="submit" name="Submit" value="Import Now" class="CommonTextButtonSmall"><input name="confirm" type="hidden" id="confirm" value="true">

        </p>
    </form>
    </td>
  </tr>
  
</table>
<br/><a name="combomax"></a>
<table width="860px" border="0" cellspacing="0" cellpadding="0"  class="mytable" >
<th>Import from ComboMax</th>
  <tr>
    <td><form name="formCombomax" method="post" action="">
      <p></p>
      <p>We will now attempt to import existing ComboMax data into Jom Comment. No data will be lost in this process. Click &quot;Import Now&quot;to proceed.           </p>
      <p>
        <input name="nounpublished" type="checkbox" id="nounpublished" value="true">
        Do not import unpublished comments </p>
      <p><input type="hidden" name="from" id="from" value="combomax" />
        <input type="submit" name="Submit" value="Import Now" class="CommonTextButtonSmall"><input name="confirm" type="hidden" id="confirm" value="true">

        </p>
    </form>
    </td>
  </tr>
  
</table>

<br/><a name="moscom"></a>
<table width="860px" border="0" cellspacing="0" cellpadding="0"  class="mytable" >
<th>Import from MosCom</th>
  <tr>
    <td><form name="formMoscom" method="post" action="">
      <p></p>
      <p>We will now attempt to import existing MosCom data into Jom Comment. No data will be lost in this process. Click &quot;Import Now&quot;to proceed. Note that due to MosCom database structure, it is not possible to import MosCom entry date information </p>
      <p>
        <input name="nounpublished" type="checkbox" id="nounpublished" value="true">
        Do not import unpublished comments </p>
      <p><input type="hidden" name="from" id="from" value="moscom" />
        <input type="submit" name="Submit" value="Import Now" class="CommonTextButtonSmall"><input name="confirm" type="hidden" id="confirm" value="true">

        </p>
    </form>
    </td>
  </tr>
</table>

<br/><a name="!JoomlaComment"></a>
<table width="860px" border="0" cellspacing="0" cellpadding="0"  class="mytable" >
<th>Import from !JoomlaComment</th>
  <tr>
    <td><form name="formMosJoomla" method="post" action="">
      <p></p>
      <p>We will now attempt to import existing !JoomlaComment data into Jom Comment. No data will be lost in this process. Click &quot;Import Now&quot;to proceed.</p>
      <p><input type="hidden" name="from" id="from" value="joomlacomment" />
        <input type="submit" name="Submit" value="Import Now" class="CommonTextButtonSmall"><input name="confirm" type="hidden" id="confirm" value="true">

        </p>
    </form>
    </td>
  </tr>
</table>

    
    <?php } } function showStatistics() { global $mosConfig_absolute_path, $database, $mainframe, $mosConfig_live_site; ?>
    <table cellpadding="4" cellspacing="0" border="0" width="100%" >
    <tr>
    <td width="100%" class="sectionname">
      <img src="components/com_jomcomment/logo.png">
    </td>
    </tr>
    </table>

<?php 
$pcTemplate = $mosConfig_absolute_path . "/administrator/components/com_jomcomment/templates/templates.jomcomment.html.php"; 
$handle = fopen($pcTemplate, "r"); 
$fdata = fread($handle, filesize($pcTemplate)); fclose($handle); 
$database->setQuery("SELECT count(*) from #__jomcomment"); 
$contentSum = $database->loadResult(); 
$fdata = str_replace("{totalComments}", $contentSum, $fdata); 
$database->setQuery("SELECT count(*) from #__jomcomment 
	                WHERE DATE_SUB(CURDATE(),INTERVAL 30 DAY) <= date"); 
					$contentSum = $database->loadResult(); 
					$fdata = str_replace("{commentThisMonth}", $contentSum, $fdata); 
					$query = (sprintf("
	            select count(*) as numComment, name, email from #__jomcomment 
	            where DATE_SUB(CURDATE(),INTERVAL 30 DAY) <= date
	            AND name != '' 
	            GROUP BY name order by numComment desc LIMIT 0, 20
	          ")); 
			  $database->setQuery($query); $result = $database->loadObjectList(); $topMember = "<ul>"; 
			  foreach ($result as $row) { 
			  	$topMember .= "<li><a href=\"mailto:$row->email\">$row->name</a> , ($row->numComment comments)</li>"; 
			} 
				  
				  $topMember .= "</ul>"; $fdata = str_replace("{topMember}", $topMember, $fdata); $query = (sprintf("
	            select count(*) as numComment, contentid from #__jomcomment 
	            where DATE_SUB(CURDATE(),INTERVAL 30 DAY) <= date
	            GROUP BY contentid order by numComment desc LIMIT 0, 20
	          ")); 
	$database->setQuery($query);
	$result = $database->loadObjectList();
	$topContent = "<ul>";
	foreach ($result as $row) {
		$database->setQuery("SELECT title from #__content WHERE id=$row->contentid");
		$contentTitle = $database->loadResult();
		$topContent .= "<li>$contentTitle</li>";
	}
	$topContent .= "</ul>";
	$fdata = str_replace("{topContent}", $topContent, $fdata);
	echo $fdata;
}
function showConfig($option) {
	global $mosConfig_absolute_path, $database, $mainframe, $mosConfig_live_site, $_JC_CONFIG;
	$file_list = mosReadDirectory($mosConfig_absolute_path . "/components/com_jomcomment/templates", "");
	$t_list = array ();
	$filecount = 0;
	foreach ($file_list as $val) {
		if (!strstr($val, "svn") && !strstr($val, "_"))
			$t_list[] = mosHTML :: makeOption($val, $val);
	}
	$templates = mosHTML :: selectList($t_list, 'template', 'class="inputbox" size="1"', 'value', 'text', $_JC_CONFIG->get('template'));
	$file_list = mosReadDirectory($mosConfig_absolute_path . "/components/com_jomcomment/languages", ".php");
	$l_list = array ();
	$filecount = 0;
	foreach ($file_list as $val) {
		if (!strstr($val, "svn"))
			$l_list[] = mosHTML :: makeOption($val, substr($val, 0, -4));
	}
	$languages = mosHTML :: selectList($l_list, 'language', 'class="inputbox" size="1"', 'value', 'text', $_JC_CONFIG->get('language'));
	$query = "SELECT id,title FROM #__sections ORDER BY title ASC";
	$database->setQuery($query);
	$rows = $database->loadObjectList();
	$sections = "<select name=\"sections[]\" size=\"" . count($rows) . "\" multiple>";
	$pc_section_array = explode(",", $_JC_CONFIG->get('sections'));
	;
	foreach ($rows as $row) {
		$sections .= "<option value='$row->id' ";
		if (in_array($row->id, $pc_section_array))
			$sections .= "selected";
		$sections .= ">$row->title</option>";
	}
	$sections .= "</select>";
	$lookup_array = explode(",", $_JC_CONFIG->get('categories'));
	;
	$lookup = array ();
	for ($i = 0; $i < count($lookup_array); $i++) {
		$lookup[$i] = new stdClass();
		$lookup[$i]->value = $lookup_array[$i];
	}
	$categories = array ();
	$query = "SELECT c.id AS `value`, c.section AS `id`, CONCAT_WS( ' / ', s.title, c.title) AS `text`" . "\n FROM #__sections AS s" . "\n INNER JOIN #__categories AS c ON c.section = s.id" . "\n WHERE s.scope = 'content'" . "\n ORDER BY s.name,c.name";
	$database->setQuery($query);
	$categories = array_merge($categories, $database->loadObjectList());
	$category_list = mosHTML :: selectList($categories, 'categories[]', 'class="inputbox" size="10" multiple="multiple"', 'value', 'text', $lookup);
	$name_list = array ();
	$name_list[] = mosHTML :: makeOption('name', "Real name");
	$name_list[] = mosHTML :: makeOption('username', "Username");
	$name_field = mosHTML :: selectList($name_list, 'username', 'class="inputbox" size="1"', 'value', 'text', $_JC_CONFIG->get('username'));
	include ($mosConfig_absolute_path . "/administrator/components/com_jomcomment/templates/config_template.php");
}

function saveConfig($option) {
	global $mosConfig_absolute_path, $database, $mosConfig_live_site, $mosConfig_cachepath, $option, $_JC_CONFIG;
	require_once ($mosConfig_absolute_path . "/administrator/components/com_jomcomment/config.jomcomment.php");
	$_JC_CONFIG->save();
	$file_list = mosReadDirectory($mosConfig_cachepath, "");
	foreach ($file_list as $val) {
		if (strstr($val, "cache_")) {
			@ unlink($mosConfig_cachepath . "/" . $val);
		}
	}
	
	// Need to rebuild the config cache
	unset($_JC_CONFIG);
	$_JC_CONFIG = new JCConfig();
	$_JC_CONFIG->rebuildCache();
	
	mosCache :: cleanCache();
	mosRedirect("index2.php?option=$option&task=config", "Settings saved");
	return;
}



function removeComments($cid, $option) {
	global $database;
	if (count($cid)) {
		$cids = implode(',', $cid);
		$database->setQuery("DELETE FROM #__jomcomment WHERE id IN ($cids)");
		if (!$database->query()) {
			echo "<script> alert('" . $database->getErrorMsg() . "'); window.history.go(-1); </script>\n";
		}
	}
	mosRedirect("index2.php?option=$option&task=comments");
}
function removeTrackbacks($cid, $option) {
	global $database;
	if (count($cid)) {
		$cids = implode(',', $cid);
		$database->setQuery("DELETE FROM #__jomcomment_tb WHERE id IN ($cids)");
		if (!$database->query()) {
			echo "<script> alert('" . $database->getErrorMsg() . "'); window.history.go(-1); </script>\n";
		}
	}
	mosRedirect("index2.php?option=$option&task=trackbacks");
}
function showAjaxedAdmin() {
	global $database, $mainframe, $option, $mosConfig_absolute_path, $mosConfig_live_site;
	$xajax = new JAX($mosConfig_live_site . "/mambots/system/pc_includes");
	if (defined('_JEXEC'))
		$xajax->setReqURI("index.php?option=com_jomcomment&no_html=1&hidemainmenu=1");
	else
		$xajax->setReqURI("index2.php?option=com_jomcomment&no_html=1&hidemainmenu=1");
	$xajax->process();
	echo "<link rel=\"stylesheet\" type=\"text/css\" href=\"$mosConfig_live_site/components/com_jomcomment/admin_style.css\" />";
?>

<script src="<?php echo $mosConfig_live_site; ?>/includes/js/tabs/tabpane_mini.js" type="text/javascript"></script>
<?php echo $xajax->getScript(); ?>
<script type="text/javascript">
jax.loadingFunction = function(){jax.$('loadingDiv').style.display='block';};
jax.doneLoadingFunction = function(){jax.$('loadingDiv').style.display='none';};
</script>
<style type="text/css">

</style>
<table width="100%"  border="0" cellspacing="4" cellpadding="6">
  <tr>
    <td width="10%" valign="top" align="center">
<?php showSidePanel() ?>
</td>
    <td width="90%" align="left" valign="top"><?php showInstallError(); ?><div id="mainAdminContent">{CONTENT}</td>
</tr>
</table>
<?php } function getAdminMenuIcon($com){ global $database, $mosConfig_live_site; $database->setQuery("SELECT admin_menu_img from #__components WHERE 
		menuid=0 AND 
		`parent`=0  AND 
		`option`='$com'"); 
		
		$icon = $database->loadResult();
if ($icon == "js/ThemeOffice/component.png")
	$icon = $mosConfig_live_site . "/includes/js/ThemeOffice/component.png";
return $icon;
}
function getPatchLink($com, $status) {
	$button = "";
	if ($status == JCHACK_STATUS_READY)
		$button = "<a onclick=\"jax.call('jomcomment', 'jcxDoPatch', '$com', 'apply');\" class=\"CommonTextButtonSmall\">Apply hacks</a>&nbsp;";
	else
		$button = "<a onclick=\"jax.call('jomcomment', 'jcxDoPatch', '$com', 'unapply');\"  class=\"CommonTextButtonSmall\">Restore backup</a>";
	return $button;
}
function showAvailableHacks() {
	global $jcPatchClass;
	$tpl = & new AzrulJXTemplate();
	$status = array ();
	$patches = array ();
	foreach ($jcPatchClass as $patch) {
		eval ("\$p = new $patch();");
		$patches[] = array (
			"name" => $p->name,
			"com" => $p->com,
			"files" => $p->files,
			"icon" => getAdminMenuIcon('com_' . $p->com
		), "status" => $p->getStatus(), "action" => getPatchLink($p->com, $p->getStatus()));
	}
	sort($patches);
	$tpl->set('patches', $patches);
	$tpl->set('publish', true);
	$html = $tpl->fetch(JC_ADMIN_COM_PATH . 'templates/hacks.tpl.html');
	echo $html;
}
function showInstallError() {
	global $database, $mosConfig_absolute_path;
	$database->setQuery("SELECT * FROM #__templates_menu");
	$template = $database->loadResult();
	if ($template) {
		$filename = $mosConfig_absolute_path . "/templates/$template/index.php";
		if (file_exists($filename)) {
			$handle = fopen($filename, "r");
			$contents = fread($handle, filesize($filename));
			fclose($handle);
			if (!strstr($contents, "mosShowHead")) {
				echo '<div align="center"><span style="color: #FF0000;font-weight: bold;font-size:16px;">Please add &quot; &lt;?php mosShowHead(); ?&gt; &quot; code within the &lt;head&gt; ... &lt;/head&gt; tag in your current joomla template!</span></div>';
			}
		}
	}
}
function showSidePanel() {
	global $mosConfig_live_site;
?>

<link rel="stylesheet" type="text/css" href="<?php echo $mosConfig_live_site; ?>/components/com_jomcomment/niftyCorners.css">
<script type="text/javascript" src="<?php echo $mosConfig_live_site; ?>/components/com_jomcomment/nifty.js"></script>
<script type="text/javascript" src="<?php echo $mosConfig_live_site; ?>/administrator/components/com_jomcomment/js/mootools.release.83.js"></script>
<script type="text/javascript">
window.onload=function(){
    if(!NiftyCheck())
        return;
    Rounded("div#sideNav","all","#FFF","#F8F8F3","border #ACA899");
}
</script>
<div class="loading" id="loadingDiv" style="display:none;position: fixed;top: 0;z-index: 100;">
<img src="<?php echo $mosConfig_live_site;?>/components/com_jomcomment/busy.gif" width="16" height="16" align="absmiddle">&nbsp;Loading...
</div>


<div style="background-color:#F8F8F3" id="sideNav">
  <table width="100%"  border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td scope="col">
<div>
  <h3 align="center">Control Panel </h3>
</div>
<div class="sideNavTitle"><img src="components/com_jomcomment/images/Options_16x16.gif" hspace="2" style="vertical-align:middle" >&nbsp;Configuration</div>
<div class="sideNavContent">
  <div class="sideNavItem"><a href="index2.php?option=com_jomcomment&task=config">General Settings </a></div>
  <div class="sideNavItem"><a href="index2.php?option=com_jomcomment&task=maintd">Maintenance </a></div>
  <div class="sideNavItem"><a href="index2.php?option=com_jomcomment&task=editLanguage">Edit Language File</a></div>
  <div class="sideNavItem"><a href="index2.php?option=com_jomcomment&task=hacks">3rd Party Components Integration</a></div>
  <div class="sideNavItem"><a href="index2.php?option=com_jomcomment&task=stats">View Statistics/Export Emails</a></div>
</div>
<div class="sideNavTitle"><img src="components/com_jomcomment/images/Documents_16x16.gif" hspace="2" style="vertical-align:middle" >&nbsp;View</div>
<div class="sideNavContent">
  <div class="sideNavItem"><a href="index2.php?option=com_jomcomment&task=comments" >View Comment </a></div>
  <div class="sideNavItem"><a href="index2.php?option=com_jomcomment&task=trackbacks" >View Trackbacks </a></div>
</div>
<div class="sideNavTitle" style="vertical-align:middle"><img src="components/com_jomcomment/images/Import_16x16.gif" hspace="2" style="vertical-align:middle" >&nbsp;Import</div>
<div class="sideNavContent">
  <div class="sideNavItem"><a href="index2.php?option=com_jomcomment&task=import#ako">Import from Ako Comment </a></div>
  <div class="sideNavItem"><a href="index2.php?option=com_jomcomment&task=import#combomax">Import from ComboMax </a></div>
  <div class="sideNavItem"><a href="index2.php?option=com_jomcomment&task=import#moscom">Import from MosCom </a></div>
  <div class="sideNavItem"><a href="index2.php?option=com_jomcomment&task=import#joomla">Import from !JoomlaComment</a></div>
  </div><div class="sideNavTitle"><img src="components/com_jomcomment/images/Information_16x16.gif" hspace="2" style="vertical-align:middle" >&nbsp;About / Support </div>
<div class="sideNavContent">
  <div class="sideNavItem"><a href="index2.php?option=com_jomcomment&task=about">About Jom Comment </a></div>
  <div class="sideNavItem"><a href="index2.php?option=com_jomcomment&task=license">License Information </a></div>
  <div class="sideNavItem"><a href="index2.php?option=com_jomcomment&task=support">Support</a></div>
  </div></td>
    </tr>
  </table>
</div>
<?php } 
