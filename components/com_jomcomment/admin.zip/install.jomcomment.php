<?php

/**
* @copyright (C) 2006 by Azrul Rahim - All rights reserved!
* @license http://www.azrul.com Copyrighted Commercial Software
**/
defined( '_VALID_MOS' ) or die( 'Restricted access' );

function deleteDir($dir){
    if (substr($dir, strlen($dir)-1, 1)!= '/')
        $dir .= '/';
    //echo $dir;
    if ($handle = opendir($dir)){
        while ($obj = readdir($handle)){
            if ($obj!= '.' && $obj!= '..'){
                if (is_dir($dir.$obj)){
                    if (!deleteDir($dir.$obj))
                        return false;
                }
                elseif (is_file($dir.$obj)){
                    if (!unlink($dir.$obj))
                        return false;
                }
            }
        }
        closedir($handle);
        if (!@rmdir($dir))
            return false;
        return true;
    }
    return false;
} 

function sysBotGetVersion(){

  	global $mosConfig_absolute_path;
  	require_once( $mosConfig_absolute_path . '/includes/domit/xml_domit_lite_include.php' );
  	
	$version = 0;
	
	$filename = $mosConfig_absolute_path . '/mambots/system/azrul.system.xml';
	if(file_exists($filename)){
		// Read the file to see if it's a valid component XML file
		$xmlDoc = new DOMIT_Lite_Document();
		$xmlDoc->resolveErrors( true );
	
		if (!$xmlDoc->loadXML( $filename, false, true )) {
			continue;
		}
	
		$root = &$xmlDoc->documentElement;
	
		if ($root->getTagName() != 'mosinstall') {
			continue;
		}
	
		$element 		= &$root->getElementsByPath('version', 1);
		$version 		= $element ? $element->getText() : '';
	}

	return doubleval($version);
}

function sysBotUpgrade($src){
    global $database, $mosConfig_absolute_path;
    $installIt = false;
    
	$botVersion = sysBotGetVersion();
    if($botVersion != 0 && $botVersion < 1.8){
    	require_once($mosConfig_absolute_path . "/administrator/includes/pcl/pclzip.lib.php");
    	
    	@deleteDir($mosConfig_absolute_path . "/mambots/system/pc_includes");
		@unlink($mosConfig_absolute_path . "/mambots/system/azrul.system.php");
		@unlink($mosConfig_absolute_path . "/mambots/system/azrul.system.xml");
		$database->setQuery("DELETE FROM #__mambots WHERE element='azrul.system'");
	    $database->query();
	    
	    $installIt = true;
	} else if($botVersion == 0){
	
		// No system bot detected, install it
		$installIt = true;
	}
	
	if($installIt){
		echo '<img src="images/tick.png"> Installing Azrul.com System mambots <br/>';
	    $archive = new PclZip($src);
	    
	    $list = $archive->extract(PCLZIP_OPT_PATH, $mosConfig_absolute_path . "/mambots/system/");
		$database->setQuery("INSERT INTO #__mambots SET name='Azrul.com System Mambot', element='azrul.system', folder='system', access=0, ordering='1', published='1'");
	    $database->query();
	    
	    // Apply chmod to 711
	    //mosChmodRecursive($mosConfig_absolute_path . "/mambots/system/pc_includes/", 0711, 0711);
	    unset($archive);
	}
}

function com_install() {
	global $database, $mosConfig_absolute_path, $mosConfig_live_site, $mosConfig_cachepath, $_VERSION;
	
	$botPath = "";
	if($_VERSION->RELEASE == "1.5"){
		$botPath = "plugins";
	} else {
		$botPath = "mambots";
	}
	
	/*
    if(@chmod($mosConfig_absolute_path . "/$botPath/system", 0777)) {
    }  else {
        echo "<b>Make sure that " . $mosConfig_absolute_path . "/$botPath/system folder is writeable!</b> <br/>";
    }
    */
    
	$database->setQuery("UPDATE #__components SET admin_menu_img='../administrator/components/com_jomcomment/icon.png' WHERE admin_menu_link='option=com_jomcomment'");
	$database->query();
	
	$database->setQuery("ALTER TABLE `#__jomcomment` MODIFY COLUMN `name` VARCHAR(200) ");
	$database->query();

    echo '
        <p><img src="components/com_jomcomment/logo.png" alt="logo" /></p>
        <p><strong>Jom Comment - A Joomla, Ajax-based User Comments Component</strong><br/>
        <code>
        <br/>';

    //add new field if it doesn't exist
    $tname = array("#__jomcomment");
    $fields = $database->getTableFields($tname);
    
    echo '<img src="images/tick.png"> Updating database <br/>';
    if(!empty($fields)){
        $prefix = "#__jomcomment";
        
        if(!array_key_exists("user_id", $fields[$prefix])){
            $query = "ALTER TABLE `#__jomcomment` ADD COLUMN `user_id` INTEGER UNSIGNED NOT NULL DEFAULT 0 AFTER `star`;";
            $database->setQuery($query);
            $database->query();
        }
        
        if(!array_key_exists("option", $fields[$prefix])){
            $query = "ALTER TABLE `#__jomcomment` ADD COLUMN `option` varchar(50) NOT NULL default 'com_content' AFTER `user_id`;";
            $database->setQuery($query);
            $database->query();
        }
    }
    
    if(!class_exists('PclZip')){
    	# for joomla 1.5
    	if(file_exists($mosConfig_absolute_path . "/libraries/pcl/pclzip.php"))
    		include_once($mosConfig_absolute_path . "/libraries/pcl/pclzip.php");
    	else
    		include_once($mosConfig_absolute_path . "/administrator/includes/pcl/pclzip.lib.php");
    }
    
   	$src  = $mosConfig_absolute_path . "/components/com_jomcomment/azrul.zip";
   	sysBotUpgrade($src);
    
    # Install jom_comment_bot
    echo '<img src="images/tick.png"> Installing Content mambots <br/>';
    $archive = new PclZip($mosConfig_absolute_path . "/components/com_jomcomment/bot.zip");
    
    $list = $archive->extract(PCLZIP_OPT_PATH, $mosConfig_absolute_path . "/$botPath/content/");
	$database->setQuery("INSERT INTO #__$botPath SET name='Jom Comment', element='jom_comment_bot', folder='content', access=0, ordering='1', published='1'");
    $database->query();
    unset($archive);
    
    

    # Install jom_commentsys_bot
    echo '<img src="images/tick.png"> Installing Jom Comment System mambots <br/>';
    $archive = new PclZip($mosConfig_absolute_path . "/components/com_jomcomment/sys.zip");
    
    $list = $archive->extract(PCLZIP_OPT_PATH, $mosConfig_absolute_path . "/$botPath/system/");
	$database->setQuery("INSERT INTO #__$botPath SET name='Jom Comment Sys', element='jom_commentsys_bot', folder='system', access=0, ordering='1', published='1'");
	$database->query();
	unset($archive);
	
	mosCache::cleanCache();
    echo '
        <img src="images/tick.png"> Loading default configurations<br/>
        <br/>
        </code>
          <font class="small">&copy; Copyright 2006 by Azrul<br/>
          This component is copyrighted commercial software. Distribution is prohibited.</font></p>
        <p><a href="htt://www.azrul.com">www.azrul.com</a></p>';
    
	# Unzip full components files
	$archive = new PclZip($mosConfig_absolute_path . "/components/com_jomcomment/com.zip");	
	$list = $archive->extract(PCLZIP_OPT_PATH, $mosConfig_absolute_path . "/components/com_jomcomment/");
    unset($archive);	
	
	# Unzip full admin files
	$archive = new PclZip($mosConfig_absolute_path . "/components/com_jomcomment/admin.zip");
	$list = $archive->extract(PCLZIP_OPT_PATH, $mosConfig_absolute_path . "/administrator/components/com_jomcomment/");
    unset($archive);	
	
	# Set captcha table to MEMORY type
	$sql = "ALTER TABLE `#__captcha_session` TYPE = InnoDB;	";
	$database->setQuery($sql);
	@$database->query();	
	
	
	// Clear cache
	$file_list = mosReadDirectory($mosConfig_cachepath, "");
	foreach ($file_list as $val) {
		if (strstr($val, "cache_")){
			@unlink($mosConfig_cachepath . "/" . $val);
		}
	}
}
