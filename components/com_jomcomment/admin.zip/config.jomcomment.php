<?php

defined('_VALID_MOS') or die('Direct Access to this location is not allowed.');
global $mosConfig_lang, $mosConfig_absolute_path, $mosConfig_live_site;
global $database, $jc_configString, $jc_defaultVals;

if(!defined('_JC_JOMCOMENT_CONFIG'))
{
	//global $mosConfig_live_site;$mosConfig_live_site/forum
	class JCConfig
	{
		var $_config 	= null;
		var $_configString = "";
		var $_defaultVars = "";
		var $_tableName 	= "#__jomcomment_config";
		
		
		var $enable               = "1";
		var $language             = "english.php";
		var $autoLang             = "0";
		var $autoPublish          = "1";
		var $anonComment          = "1";
		var $moreInfo             = "1";
		var $useBBCode            = "1";
		var $useSmilies           = "1";
		var $useRSSFeed           = "1";
		var $autoUpdate           = "0";
		var $updatePeriod         = "300";
		var $staticContent        = "0";
		var $limitSection         = "0";
		var $sections             = "0";
		var $limitCategory		  = "1";
		var $categories			  = "1,2,3";
		var $notifyAdmin          = "0";
		var $notifyEmail          = "";
		var $useCaptcha           = "0";
		var $blockDomain          = "";
		var $blockUsers           = "";
		var $blockWords           = "";
		var $censoredWords        = "";
		var $postInterval         = "30";
		var $template             = "default";
		var $sortBy               = "1";
		var $cycleStyle           = "jomentry1,jomentry2";
		var $textWrap             = "55";
		var $alertBgColor         = "#FAD163";
		var $aletrFontColor       = "#000000";
		var $dateFormat           = "%B %d, %Y";
		var $useReadMore          = "1";
		var $useSelectiveReadMore = "0";
		var $gravatar             = "gravatar";
		var $gWidth               = "40";
		var $gHeight              = "40";
		var $hideForm             = "1";
		var $modGuest             = "0";
		var $fieldWebsite         = "1";
		var $fieldTitle           ="1";
		var $useCaptchaRegistered = "0";
		var $showBlogViewLink     = "1";
		var $showCommentCount	  = "1";
		var $showHitCount		  = "1";
		var $linkNofollow         = "1";
		var $startFormHidden      = "0";
		var $startAreaHidden      = "0";
		var $slideComment         = "0";
		var $slideForm            = "0";
		var $linkGravatar         = "none";
		var $spamLinkStuff        = "1";
		var $spamMaxLink          = "2";
		var $commentMinLen        = "8";
		var $commentMaxLen        = "5000";
		var $maxCommentHalfHour   = "20";
		var $authorStyle          = "jomauthor";
		var $notifyAuthor         = "0";
		var $useEmailSubs         = "1"; // allow email subscription to comment
		var $fieldEmail           = "1";
		var $paginate             = "0";
		var $multiLanguage		 = "0";
		var $enableTrackback	 = "0";
		var $trackbackShow		 = "10";
		var $useLinkback		 = "1";
		var $smfPrefix			 = "smf";
		var $smfWrapped			 = "1";
		var $smfPath			 = "";
		var $optimiseEncoding	 = "0";
		var $lockAfter			 = "0";
		var $remoteSpam			 = "0";
		var $username			 = "name";
		var $paging				 = "0";	// Pagination, 0 = no pagination
		var $akismetKey			 = "";
		var $allowedTags		 = "";
		var $extComSupport		 = "1";
		
		
		function JCConfig(){
			global $database, $mosConfig_absolute_path, $mosConfig_lang;
			
			# If the config cache file exist, load it, otherwise, load it from the 
			# database
			
			/*
			if(file_exists($mosConfig_absolute_path . '/administrator/components/com_jomcomment/config.php')){
				$config = array();
				require($mosConfig_absolute_path . '/administrator/components/com_jomcomment/config.php');
				foreach($config as $key => $val){
					$this->$key = $val; 
				}
			}
			*/
						
			$database->setQuery("SELECT value FROM $this->_tableName WHERE name='all'");
			$this->_configString = $database->loadResult();
			
			# Save default config in the database if none exist
			if(!$this->_configString){
			
				# Start with default language file
				if (file_exists(JC_BOT_PATH . "languages/" . $mosConfig_lang . ".php"))
					$this->language = $mosConfig_lang . '.php';
				
				# insert default values	
				$default_vars = get_class_vars('JCConfig');
				$this->_configString = "";
				foreach ($default_vars as  $name => $value) {
					if(substr($name, 0, 1) != "_")
						$this->_configString .= "\$$name = \"" . strval($value) ."\";\n";
				}
				
				$database->setQuery("INSERT INTO $this->_tableName SET value='$this->_configString', name='all'");
				$database->query();
							
			} else if(substr($this->_configString, 0, 4) == '$pc_'){
				# If the data is in old format, we need to update them
				$this->_configString = str_replace('$pc_', '$', $this->_configString);
				$database->setQuery("UPDATE $this->_tableName SET value='$this->_configString', name='all'");
				$database->query();
					
			} else if(strpos($this->_configString, '$sections')){
				# If the data contain '$section', we need to convert them to category listing
				$sections = "";
				eval($this->_configString);
				$sectionsArray = explode(",", $sections);
				$sections = str_replace(",", '","', $sections);
				$sections = "\"$sections\"";
				
				$database->setQuery("SELECT `id` FROM #__categories WHERE `section` IN ($sections)");
				$cats = $database->loadObjectList();
				foreach($cats as $cat){
					$this->categories .= "$cat->id,";
				}
				$this->categories = substr($this->categories, 0, -1);
			}
			
			$cfg = str_replace('$', '$this->', $this->_configString);
			eval($cfg);
			
			
			
			# Need to set up multi language support (JoomFish)
			if($this->autoLang){			
				$lang_file = "$mosConfig_lang.php";
				if(file_exists(JC_BOT_PATH ."languages/$lang_file")){
					$this->language = $lang_file;
				}
			}
			
			# compatbility for version 1.6 upwards
			if($this->dateFormat == "F j, Y"){
			    $this->dateFormat= "%B %d, %Y";
			}
			
			if(substr($this->template, -5) == ".html"){
			    $this->template = substr($this->template, 0, -5);
			}
			
			# If template is not available, revert to 'default' template
			if (!file_exists(JC_BOT_PATH."templates/" . $this->template)) {
			    $this->template = "default";
			}
			
			# Set section to all section/category if none is selected
			if($this->sections == "0"){
				$database->setQuery("SELECT id FROM #__sections");
				$secs = $database->loadResult();
				$this->sections = "";
				for($i = 0; $i < count($secs); $i++){
					$this->sections .= "," . strval($secs[$i]);
				}
				
			}
		}
		
		# Return current config string. We also need to load up uninitialised
		# configuration		 	 		
		function getConfigString(){
			$varString = $this->_defaultVars . $this->_configString;
			return $varString;
		}
		
		function get($varname, $default="0"){
			if(isset($this->$varname)){
				return $this->$varname;
			}else{
				return $default;
			}
		}
		
		function addBlockedIP($ip) { 
			global $database;
			$database->setQuery("SELECT value FROM $this->_tableName WHERE name='all'");
			$configStr = $database->loadResult();
			$configStr = str_replace('$blockDomain= "', '$blockDomain= "' . $ip . ',', $configStr);
			$database->setQuery("UPDATE $this->_tableName SET value='$configStr' WHERE name='all'");
			$database->query();
		}
		
		function addBlockedUser($username) { 
			global $database;
			$database->setQuery("SELECT value FROM $this->_tableName WHERE name='all'");
			$configStr = $database->loadResult();
			$configStr = str_replace('$blockUsers= "', '$blockUsers= "' . $username . ',', $configStr);
			$database->setQuery("UPDATE $this->_tableName SET value='$configStr' WHERE name='all'");
			$database->query();
		}
		
		# Take all $_POST vars, create a string and save it	 		
		function save(){
			global $database;

			$config = "";
			$postvar = array_keys($_POST);
			foreach ($postvar as $var) {
				if (is_array($_POST[$var])) {
					$ls = implode(",", $_POST[$var]);
					$config .= "\$$var= \"$ls\";\n";
				} else {
					$config .= "\$$var= \"$_POST[$var]\";\n";
				}
			}
		
			$config = addslashes($config);
			$database->setQuery("UPDATE $this->_tableName SET value='$config', name='all'");
			$database->query();
		}
		
		function rebuildCache(){
			global $database, $mosConfig_absolute_path;
			$database->setQuery("SELECT value FROM #__jomcomment_config WHERE name='all'");
			$configString = $database->loadResult();
			
			$configString = str_replace('$', '$config[\'', $configString);
			$configString = str_replace('= "', "'] = \"", $configString);
			
			
			$configString = '<?php $config = array(); ' . $configString;
			$filename = $mosConfig_absolute_path . "/administrator/components/com_jomcomment/config.php";
			if (!$handle = fopen($filename, 'w')) {
				echo "Cannot open file ($filename)";
				exit;
			}
			
			// Write $somecontent to our opened file.
			if (fwrite($handle, $configString) === FALSE) {
				echo "Cannot write to file ($filename)";
				exit;
			}
			
			fclose($handle);
		
		}
	}
		
	define('_JC_JOMCOMENT_CONFIG', 1);
}
