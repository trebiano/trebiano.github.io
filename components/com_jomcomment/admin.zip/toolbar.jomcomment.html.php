<?php
/**
* @copyright (C) 2006 by Azrul Rahim - All rights reserved!
* @license http://www.azrul.com Copyrighted Commercial Software
**/
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );

class menujomcomment {
    function CONFIG_MENU() {
    mosMenuBar::startTable();
    mosMenuBar::save( 'savesettings', 'Save Settings' );
    mosMenuBar::back();
    mosMenuBar::spacer();
    mosMenuBar::endTable();
  }

   function FILE_MENU() {
    mosMenuBar::startTable();
    mosMenuBar::save();
    mosMenuBar::cancel();
    mosMenuBar::spacer();
    mosMenuBar::endTable();
  }

  function ABOUT_MENU() {
    mosMenuBar::startTable();
    mosMenuBar::back();
    mosMenuBar::spacer();
    mosMenuBar::endTable();
  }
  
  function STATS_MENU() {
    mosMenuBar::startTable();
    mosMenuBar::back();
    mosMenuBar::spacer();
    mosMenuBar::endTable();
  }
  
  function IMPORT_MENU() {
    mosMenuBar::startTable();
    mosMenuBar::back();
    mosMenuBar::spacer();
    mosMenuBar::endTable();
  }
  
  function TRACKBACK_MENU() {
    mosMenuBar::startTable();
    mosMenuBar::publish('publish_tb', 'Publish');
    mosMenuBar::unpublish('unpublish_tb', 'Unpublish');
    mosMenuBar::deleteList('', 'remove_tb', 'Remove');
    mosMenuBar::endTable();
  }
  
  function MENU_Default() {
    mosMenuBar::startTable();
    mosMenuBar::publish();
    mosMenuBar::unpublish();
    mosMenuBar::deleteList();
    mosMenuBar::endTable();
  }
}

