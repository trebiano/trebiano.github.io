<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );

function deleteDir($dir){
    if (substr($dir, strlen($dir)-1, 1)!= '/')
        $dir .= '/';
    
    if ($handle = opendir($dir)){
        while ($obj = readdir($handle)){
            if ($obj!= '.' && $obj!= '..'){
                if (is_dir($dir.$obj)){
                    if (!deleteDir($dir.$obj))
                        return false;
                }
                elseif (is_file($dir.$obj)){
                    if (!unlink($dir.$obj))
                        return false;
                }
            }
        }
        closedir($handle);
        if (!@rmdir($dir))
            return false;
        return true;
    }
    return false;
} 

function com_uninstall() {
	
    global $database, $mosConfig_absolute_path, $mosConfig_live_site;
	global $_VERSION;
	
	$botPath = "mambots";
	if(isset($_VERSION) && ($_VERSION->RELEASE == "1.5")){
		$botPath = "plugins";
	} else {
		$botPath = "mambots";
	}
	
	# Uninstall jom_comment_bot
	unlink($mosConfig_absolute_path . "/$botPath/content/jom_comment_bot.php");
	unlink($mosConfig_absolute_path . "/$botPath/content/jom_comment_bot.xml");
	$database->setQuery("DELETE FROM #__$botPath WHERE name='Jom Comment'");
    $database->query();
    
    # No need to remove the system mambots
    
    # Uninstall jom_commentsys_bot
    unlink($mosConfig_absolute_path . "/$botPath/system/jom_commentsys_bot.php");
    unlink($mosConfig_absolute_path . "/$botPath/system/jom_commentsys_bot.xml");
    $database->setQuery("DELETE FROM #__$botPath WHERE name='Jom Comment Sys'");
    $database->query();    
    
    # Delete com_jomcomment
    deleteDir($mosConfig_absolute_path . "/components/com_jomcomment");
	#@deleteDir($mosConfig_absolute_path . "/administrator/components/com_jomcomment");
	
	return true;    
}
